#!/usr/bin/env python3
# Python 3.9+ — PS4 LAN host and raw binary sender; no third-party dependencies.
import http.server
import ipaddress
import json
import os
from pathlib import Path
import socket
import sys
from urllib.parse import urlsplit, unquote

ROOT = Path(__file__).resolve().parent.parent
PAYLOAD_DIR = ROOT / 'payloads'
PORT = int(os.environ.get('ONYX_PORT', '8000'))
PORTS = {9020, 9090, 1337}
MAX_PAYLOAD_SIZE = 32 * 1024 * 1024


class Host(http.server.SimpleHTTPRequestHandler):
    server_version = 'AlexGoldHEN-LAN/2.0'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def send_json(self, status, value):
        binary = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(binary)))
        self.end_headers()
        self.wfile.write(binary)

    def peer_ip(self):
        try:
            ip = ipaddress.ip_address(self.client_address[0])
            if ip.version == 4 and ip.is_private and not ip.is_loopback and not ip.is_link_local:
                return str(ip)
        except ValueError:
            pass
        return None

    def from_ps4(self):
        agent = self.headers.get('User-Agent', '').lower()
        return 'playstation 4' in agent or 'ps4' in agent

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == '/api/device':
            ps4 = self.from_ps4()
            ip = self.peer_ip() if ps4 else None
            self.send_json(200, {'local': bool(ip), 'ip': ip, 'ps4': ps4})
            return
        # Serve only the required public site files. Never expose the private payload binaries.
        if path not in ('/', '/index.html', '/style.css', '/app.js', '/config.js', '/assets/alexgoldhen.webp', '/assets/onyxai.webp'):
            self.send_error(404, 'Not found')
            return
        super().do_GET()

    def do_POST(self):
        if urlsplit(self.path).path != '/api/send':
            self.send_json(404, {'ok': False, 'message': 'Unknown endpoint'})
            return
        if not self.from_ps4() or not self.peer_ip():
            self.send_json(403, {'ok': False, 'message': 'Open this page on the PS4 from the LAN host'})
            return
        if self.headers.get('X-Onyx-Request') != 'payload':
            self.send_json(403, {'ok': False, 'message': 'Missing request marker'})
            return
        origin = self.headers.get('Origin', '')
        if origin and urlsplit(origin).netloc != self.headers.get('Host', ''):
            self.send_json(403, {'ok': False, 'message': 'Cross-origin request blocked'})
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            size = 0
        if not 0 < size <= 1024:
            self.send_json(413, {'ok': False, 'message': 'Invalid request size'})
            return
        try:
            body = json.loads(self.rfile.read(size).decode('utf-8'))
            filename = body['file']
            port = int(body['port'])
        except (ValueError, UnicodeDecodeError, KeyError, TypeError):
            self.send_json(400, {'ok': False, 'message': 'Invalid JSON or payload choice'})
            return
        if filename not in ('goldhen.bin', 'hen.bin') or port not in PORTS:
            self.send_json(400, {'ok': False, 'message': 'Unsupported filename or TCP port'})
            return
        path = PAYLOAD_DIR / filename
        if not path.is_file():
            self.send_json(404, {'ok': False, 'message': 'Missing local file: payloads/' + filename})
            return
        if not 0 < path.stat().st_size <= MAX_PAYLOAD_SIZE:
            self.send_json(400, {'ok': False, 'message': 'Invalid binary file length'})
            return
        ip = self.peer_ip()  # The PS4 browser peer; cannot be supplied by the caller.
        count = 0
        try:
            with path.open('rb') as reader, socket.create_connection((ip, port), 6) as sock:
                sock.settimeout(15)
                while True:
                    chunk = reader.read(65536)
                    if not chunk:
                        break
                    sock.sendall(chunk)
                    count += len(chunk)
                try:
                    sock.shutdown(socket.SHUT_WR)
                except OSError:
                    pass
            self.send_json(200, {'ok': True, 'message': f'{filename}: {count} bytes enviados para {ip}:{port}'})
        except (OSError, TimeoutError) as exc:
            self.send_json(502, {'ok': False, 'message': f'Falha TCP {ip}:{port}: {str(exc)[:120]}'})


if __name__ == '__main__':
    PAYLOAD_DIR.mkdir(exist_ok=True)
    try:
        with http.server.ThreadingHTTPServer(('0.0.0.0', PORT), Host) as server:
            print(f'AlexGOLDHEN OnyxAI LAN: porta {PORT}')
            print(f'No navegador PS4 abra http://IP_DO_SEU_PC:{PORT}/')
            print('Arquivos localizados em:', ROOT)
            server.serve_forever()
    except OSError as exc:
        sys.exit(f'Falha ao iniciar o servidor: {exc}')
