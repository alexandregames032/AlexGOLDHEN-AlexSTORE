// Cloudflare Pages Function — Google Cloud Translation API v2 (server-side).
// Configure GOOGLE_TRANSLATE_API_KEY in Pages > Settings > Environment variables (secret).
const json = (value, status=200) => new Response(JSON.stringify(value),{
  status, headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}
});
export async function onRequestPost({request,env}) {
  if (!env.GOOGLE_TRANSLATE_API_KEY) return json({error:'Translation key not configured'},503);
  const length=Number(request.headers.get('content-length')||0);
  if (length>24000) return json({error:'Request too large'},413);
  let data;
  try { data=await request.json(); } catch(e) { return json({error:'Invalid JSON'},400); }
  const {texts,source='pt',target} = data || {};
  if(!Array.isArray(texts)||texts.length<1||texts.length>100||texts.some(x=>typeof x!=='string'||x.length>1200) || texts.join('').length>16000) return json({error:'Invalid texts'},400);
  if(typeof target!=='string'||!/^[A-Za-z]{2,4}(?:-[A-Za-z]{2,8})?$/.test(target)) return json({error:'Invalid language code'},400);
  if(typeof source!=='string'||!/^[A-Za-z]{2,4}(?:-[A-Za-z]{2,8})?$/.test(source)) return json({error:'Invalid source language'},400);
  const url='https://translation.googleapis.com/language/translate/v2?key='+encodeURIComponent(env.GOOGLE_TRANSLATE_API_KEY);
  let response;
  try {response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({q:texts,source,target,format:'text'})});}
  catch(e){return json({error:'Translation provider unreachable'},502);}
  const result=await response.json().catch(()=>({}));
  if(!response.ok) return json({error:'Translation provider rejected language or request'},502);
  const translated=result?.data?.translations;
  if(!Array.isArray(translated)||translated.length!==texts.length) return json({error:'Malformed translation response'},502);
  return json({translations:translated.map(item=>String(item.translatedText||''))});
}
