// Browser-side configuration for AlexGOLDHEN.
// Never store a Google Cloud API key here. Keys belong in server-side secrets.
// Cloudflare Pages: the function at /api/translate is available automatically.
// GitHub Pages: set window.ONYX_TRANSLATE_ENDPOINT to your external HTTPS endpoint.
window.ONYX_TRANSLATE_ENDPOINT = '';
