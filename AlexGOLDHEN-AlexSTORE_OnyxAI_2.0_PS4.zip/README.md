# AlexGOLDHEN — OnyxAI 2.0

Portal PS4 em **português brasileiro**, com duas logos originais do projeto, visual preto/dourado, interface responsiva, detector OnyxAI, rotas de exploit, oito fontes Google Fonts, seletor de mais de 120 línguas e transmissor de binários em rede local.

## Rotas configuradas

| Firmware | Interface | Execução | Código fonte |
| --- | --- | --- | --- |
| 4.55–10.01 | WebKIT | https://webkitty.arabpixel.net/ | https://github.com/ArabPixel/WebKitty |
| 11.00–13.00 | SlopKIT | https://rawgame4.github.io/ | https://github.com/rawgame4/rawgame4.github.io |
| 13.02–13.52 | SlopKIT Relapse | https://raw13g.github.io/ | https://github.com/raw13g/raw13g.github.io |
| 14.00–14.02 | AfterGLOW | https://well0nez.github.io/afterglow-web/ | https://github.com/well0nez/afterglow-web |

**Importante:** as faixas são rótulos de seleção do portal. A execução depende da versão exata. O 14.02 ainda não tem suporte publicamente confirmado no host oficial (a página diz “14.02 soon”). O botão fica desativado para 14.02. A rota 10.01 também não é marcada como validada: a cadeia RawGame4 contém offsets 10.01 ainda não testados em hardware. Consulte o host original para as listas exatas de cada versão.

O portal **não contém um kernel exploit novo embutido**: ele detecta e encaminha o PS4 aos hosts públicos funcionais. Esses hosts executam suas respectivas cadeias de exploração; o sucesso não pode ser presumido.

## Abrir no navegador PS4 (GitHub Pages)

Coloque o conteúdo desta pasta na raiz do repositório `AlexGOLDHEN-AlexSTORE` e ative **Settings → Pages → Deploy from a branch → main / (root)**. Depois abra a URL do Pages no navegador do PS4.

Sem servidor LAN, o site consegue identificar tipo de navegador e firmware (quando declarado no User-Agent), mas **não** consegue descobrir o IP privado nem abrir diretamente uma conexão TCP com o PS4.

## IP privado e envio de goldhen.bin / hen.bin

É necessário que PS4 e computador estejam na mesma rede LAN, que um exploit já tenha preparado um **payload listener TCP** no PS4 e que o binário escolhido corresponda ao firmware e ao loader.

1. Tenha Python 3.9 ou superior instalado no PC.
2. Coloque seu próprio `goldhen.bin` e/ou `hen.bin` em `payloads/`. Este ZIP não inclui os binários.
3. Execute na raiz do projeto:

   ```bash
   python3 tools/lan_host.py
   ```

   No Windows:

   ```powershell
   py tools\lan_host.py
   ```

4. Descubra o IPv4 do computador (ex.: `192.168.1.20`) e abra **no navegador do PS4** `http://192.168.1.20:8000/`.
5. OnyxAI mostrará o IP observado diretamente da conexão; ele será o destino do transmissor.
6. Depois que o payload listener do console estiver aberto, escolha a porta (9090, 9020 ou 1337), selecione o binário e clique **Enviar ao PS4**.
7. O programa envia exatamente os bytes do arquivo; ele não faz exploit por conta própria. Se a porta estiver fechada, verá um erro TCP.

**Rede local:** a interface precisa estar carregada pelo servidor do PC. Não há mecanismo confiável para um site remoto do GitHub Pages descobrir o endereço privado do visitante e criar conexões TCP arbitrárias.

## Idiomas e Google Fonts

O seletor inclui mais de 120 códigos de idioma, priorizando idiomas amplamente utilizados. O conteúdo base é pt-BR; há fallback parcial de inglês e espanhol incorporado ao JS. **A tradução integral não opera sem API.** Cada idioma também depende de suporte do Google Cloud Translation.

Para traduzir a interface por Google Cloud Translation API v2:

1. Habilite **Cloud Translation API** no projeto Google Cloud.
2. Faça o deploy deste projeto no **Cloudflare Pages** (build command vazio; diretório de saída `.`).
3. Cadastre `GOOGLE_TRANSLATE_API_KEY` como variável secreta no Cloudflare Pages.
4. A função `functions/api/translate.js` ficará disponível em `/api/translate` e será selecionada automaticamente quando o domínio terminar em `pages.dev`.
5. Em outros domínios, defina `window.ONYX_TRANSLATE_ENDPOINT` em `config.js` para o endpoint autorizado. Para cross-origin, configure CORS no serviço.

As fontes vêm do Google Fonts e exigem conexão de rede. Opções: **Rajdhani, Orbitron, Inter, Oxanium, Exo 2, Sora, Audiowide, Chakra Petch**.

## Estrutura

- `index.html` — UI
- `style.css` — tema Neon Gold / Liquid Glass
- `app.js` — OnyxAI, roteamento, idiomas, fontes e envio local
- `config.js` — configuração pública de endpoint
- `assets/` — logos do usuário, convertidas para WebP
- `functions/api/translate.js` — Cloudflare Pages Function de tradução
- `tools/lan_host.py` — servidor LAN HTTP + cliente TCP do listener
- `payloads/` — inserir arquivos binários próprios

## Repositório

https://github.com/alexandregames032/AlexGOLDHEN-AlexSTORE

Gerado em 11/11/2026. Verificação funcional do JavaScript e servidor HTTP realizada em ambiente de teste. Não houve validação física em um console PS4.

## Arte original

As duas imagens PNG fornecidas para a identidade visual estão em `assets/originais/`. O site utiliza versões WebP otimizadas para carregar mais rapidamente.
